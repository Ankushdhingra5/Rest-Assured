package excelTest;

import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.ExcelUtil;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class ExcelTest extends BaseTest {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://reqres.in"; // Replace with your base URI
    }

    @DataProvider(name = "excelDataProvider")
    public Iterator<Object[]> excelDataProvider() throws IOException {
        List<Object[]> data = ExcelUtil.getExcelData(System.getProperty("user.dir")+"/src/main/resources/dataForTesting.xlsx");
        return data.iterator();
    }

    @Test(dataProvider = "excelDataProvider")
    public void testAPIWithExcelData(String endpoint, String param1, String expectedId, String expectedEmail,
                                     String expectedFirstName, String expectedLastName, String expectedAvatar,
                                     String expectedSupportUrl, String expectedSupportText) {

        // Convert param1 to integer to remove any decimal points
        int userId = (int) Double.parseDouble(param1);
        int expected = (int) Double.parseDouble(expectedId);

        System.out.println("Testing endpoint: " + endpoint + "/" + userId);

        Response response = given()
                            .when()
                                .get(endpoint + "/" + userId) // Use userId as path parameter
                            .then()
                                .extract().response();

        // Print response details for debugging
        System.out.println("Response Status Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());

        // Validate status code
        assertThat("The status code should be 200", response.getStatusCode(), equalTo(200));

        // Validate data fields
        assertThat("The ID should match", response.path("data.id").toString(), equalTo(String.valueOf(expected)));
        assertThat("The email should match", response.path("data.email"), equalTo(expectedEmail));
        assertThat("The first name should match", response.path("data.first_name"), equalTo(expectedFirstName));
        assertThat("The last name should match", response.path("data.last_name"), equalTo(expectedLastName));
        assertThat("The avatar URL should match", response.path("data.avatar"), equalTo(expectedAvatar));

        // Validate support fields
        assertThat("The support URL should match", response.path("support.url"), equalTo(expectedSupportUrl));
        assertThat("The support text should match", response.path("support.text"), equalTo(expectedSupportText));
    }
}
