package excelTest;

import baseTest.BaseTest;
import io.restassured.response.Response;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.ExcelUtil;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class ExcelTestSample extends BaseTest {

//    @BeforeClass
//    public void setup() {
//        RestAssured.baseURI = "https://reqres.in"; // Replace with your base URI
//    }

    @DataProvider(name = "excelDataProvider")
    public Iterator<Object[]> excelDataProvider() throws IOException {
        List<Object[]> data = ExcelUtil.getExcelData("/Users/AnkushDhingra/Prep/excelDataInput.xlsx");
        return data.iterator();
    }

    @Test(dataProvider = "excelDataProvider")
    public void testAPIWithExcelData(String endpoint, String param1, String expectedResponse) {
        System.out.println("Testing endpoint: " + endpoint + " with param1: " + param1 + " expecting email: " + expectedResponse);
        int userId = (int) Double.parseDouble(param1);
        Response response = given()
                            .when()
                                .get(endpoint + "/" + userId)
                            .then()
                                .statusCode(200)
                                .extract().response();
        // Print response details for debugging
        System.out.println("Response Status Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());

//         Extract email from the response
        String actualEmail = response.path("data.email");
        System.out.println("actualEmail: " + actualEmail);
        response.then().body("data.email", equalTo(expectedResponse)); // Adjust key as per your response structure
    }
}
