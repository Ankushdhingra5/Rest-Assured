package org.practise;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.equalTo;

public class YourTestClass3 {

    @Test
    public void yourTestMethod() {
        // Define path parameters
        Map<String, Object> pathParams = new HashMap<>();
        pathParams.put("q", 2); // path parameter q

        // Define query parameters
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("a", "b"); // query parameter a
        queryParams.put("c", "d"); // query parameter c

        // Create request specification
        RequestSpecification requestSpec = RestAssured.given()
                .params(pathParams) // Set path parameters
                .params(queryParams); // Set query parameters

        // Create response specification
        ResponseSpecification responseSpec = RestAssured.expect()
                .statusCode(200); // Expected status code

        // Perform the request using the specification
        Response response = requestSpec
                .when()
                .get("/users");

        // Validate the response against the expected status code using the response specification
        response.then().spec(responseSpec);

        // Verify a specific value in the response body
        response.then().assertThat()
                .body("path.to.your.value", equalTo("expectedValue")); // Specify the JSON path to your value and the expected value
    }
}

