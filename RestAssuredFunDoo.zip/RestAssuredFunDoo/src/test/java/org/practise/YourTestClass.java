package org.practise;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class YourTestClass {

    @Test
    public void yourTestMethod() {
        RestAssured.baseURI = "http://localhost:8080";
        // Prepare nested JSON request body
        String requestBody = "{\n" +
                "  \"user\": {\n" +
                "    \"name\": \"John\",\n" +
                "    \"email\": \"john@example.com\",\n" +
                "    \"address\": {\n" +
                "      \"city\": \"New York\",\n" +
                "      \"zipcode\": \"10001\"\n" +
                "    }\n" +
                "  }\n" +
                "}";

        // Perform POST request and get the response
        Response response = RestAssured.given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post("/createUser");

        // Assert status code
        assertEquals(200, response.getStatusCode());

        // Verify nested JSON values in the response
        String name = response.jsonPath().getString("user.name");
        assertEquals("John", name);

        String email = response.jsonPath().getString("user.email");
        assertEquals("john@example.com", email);

        String city = response.jsonPath().getString("user.address.city");
        assertEquals("New York", city);

        String zipcode = response.jsonPath().getString("user.address.zipcode");
        assertEquals("10001", zipcode);

        // You can add more assertions as needed
    }
}
