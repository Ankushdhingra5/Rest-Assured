package org.practise;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

public class YourTestClass2 {

    @Test
    public void yourTestMethod() {
        RestAssured.baseURI = "https://pokeapi.co";

        // Perform POST request and get the response
        Response response = RestAssured.given()
                .contentType("application/json")
                .when()
                .get("/api/v2/pokemon/ditto");

        // Assert status code
        assertEquals(200, response.getStatusCode());

        // Verify nested JSON values in the response
        String name = response.jsonPath().getString("abilities[0].ability.name");
        assertEquals("limber", name);

        String email = response.jsonPath().getString("weight");
        assertEquals("40", email);

        String city = response.jsonPath().getString("types[0].type.name");

        assertEquals("normal", city);
        response.then().assertThat()
                .body("types[0].type.name", equalTo("normal"));


//        Deserialize JSON response to User object using Gson
//        Gson gson = new Gson();
//        User user = gson.fromJson(response.getBody().asString(), User.class);


//        Deserialize JSON response to User object using Jackson
//        ObjectMapper objectMapper = new ObjectMapper();
//        User user = objectMapper.readValue(response.getBody().asString(), User.class);


//        In summary, if you need advanced features, high performance, and extensive customization options,
//        Jackson might be the better choice. However, if you prefer simplicity, ease of use, and
//        lightweight dependency footprint, Gson could be a more suitable option for your project.

    }
}
