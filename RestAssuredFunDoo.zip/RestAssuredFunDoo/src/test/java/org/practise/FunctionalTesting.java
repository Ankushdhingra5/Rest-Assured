package org.practise;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
public class FunctionalTesting {

    @Test
    public void getRequestAutomation(){
    RestAssured.baseURI="https://reqres.in/api/users";

        Response response=RestAssured.given().param("page","2").when().get();
        System.out.println(response.statusCode());
        System.out.println(response.prettyPrint());
    }

    @Test
    public void postRequestAutomation(){
        RestAssured.baseURI="https://reqres.in/api/users";
        String json="{\n" +
                "    \"name\": \"morpheus\",\n" +
                "    \"job\": \"leader\"\n" +
                "}";
        Response response=RestAssured.given().body(json).when().post();
        System.out.println(response.statusCode());
        System.out.println(response.prettyPrint());
    }
}