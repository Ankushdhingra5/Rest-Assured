package studentApiTest;

import io.restassured.RestAssured;
import org.testng.annotations.Test;
import pojo.DataDto;
import pojo.ListUsersPojo;

import java.util.List;

public class DeSerializatedTests {
   @Test
    public void DSerialTest(){
       RestAssured.baseURI="https://reqres.in/api/users?page=2";

       ListUsersPojo listUsersPojo=RestAssured.given().when().get().as(ListUsersPojo.class);
       System.out.println(listUsersPojo);

      System.out.println(listUsersPojo.getData());

      List<DataDto> dtoList=listUsersPojo.getData();

       for (int i=0;i<dtoList.size();i++){
          System.out.println(dtoList.get(i));
       }
   }
}
