package studentApiTest;

import apiConfigs.HeaderConfigs;
import apiConfigs.apiPath;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import pojo.PostApiPojo;

public class SerializedApiTests extends BaseTest {
    @Test
    public void serTest1(){
        HeaderConfigs headerConfigs=new HeaderConfigs();
        PostApiPojo postApiPojo=new PostApiPojo("test name","test job");
        System.out.println(postApiPojo);

        Response response= RestAssured.given().when().headers(headerConfigs.defaultHeaders())
                .body(postApiPojo).when().post(apiPath.APIPath.CREATE_USER);

        System.out.println(response.getBody().asString());
        System.out.println(postApiPojo.getJob());
        System.out.println(postApiPojo.getName());

    }
}
