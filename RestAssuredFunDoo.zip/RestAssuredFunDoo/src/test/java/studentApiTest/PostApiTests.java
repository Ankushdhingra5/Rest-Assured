package studentApiTest;

import apiBuilders.PostApiBuilder;
import apiConfigs.HeaderConfigs;
import apiConfigs.apiPath;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
//import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;
import utils.JavaUtils;

import java.util.Random;

public class PostApiTests extends BaseTest {

    @Test
    public void validPostApiTest(){

        HeaderConfigs headerConfigs=new HeaderConfigs();
        PostApiBuilder postApiBuilder=new PostApiBuilder();

        Response response=RestAssured.given().headers(headerConfigs.defaultHeaders())
                .body(postApiBuilder.postBodyBuilder(JavaUtils.randomString(),JavaUtils.randomString())).when().post(apiPath.APIPath.CREATE_USER);



        APIVerification.responseCodeValidator(response,201);
        APIVerification.responseKeyValidator(response,"name");
        APIVerification.responseTimeValidator(response);

//        test.log(LogStatus.INFO,"Test has been ended......");

    }
}
