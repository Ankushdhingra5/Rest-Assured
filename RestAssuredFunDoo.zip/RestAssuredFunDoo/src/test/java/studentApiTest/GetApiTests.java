package studentApiTest;

import apiConfigs.apiPath;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import org.testng.annotations.Test;

public class GetApiTests extends BaseTest {

    @Test
    public void getApiTest(){
//        RestAssured.given().when().get(apiPath.APIPath.GET_LIST_OF_USERS).then().log().all().statusCode(200);

        Response response=RestAssured.given().when().get(apiPath.APIPath.GET_LIST_OF_USERS);

        APIVerification.responseCodeValidator(response,400);
        APIVerification.responseKeyValidator(response,"page");
        APIVerification.responseTimeValidator(response);
    }
}
