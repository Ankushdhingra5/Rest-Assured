package jsonTest;

import baseTest.BaseTest;
import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pojo.UserData;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class JsonSampleTest extends BaseTest {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://reqres.in"; // Replace with your base URI
    }

    @DataProvider(name = "jsonDataProvider")
    public Object[][] jsonDataProvider() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        List<UserData> data = objectMapper.readValue(
                new File(System.getProperty("user.dir")+"/src/main/resources/data.json"),
                objectMapper.getTypeFactory().constructCollectionType(List.class, UserData.class)
        );
        Object[][] dataArray = new Object[data.size()][1];
        for (int i = 0; i < data.size(); i++) {
            dataArray[i][0] = data.get(i);
        }
        return dataArray;
    }

    @Test(dataProvider = "jsonDataProvider")
    public void testAPIWithJsonData(UserData userData) {

        // Convert param1 to integer to remove any decimal points
        String fullEndpoint = userData.getEndpoint() + "/" + userData.getParam1();
        System.out.println("Testing endpoint: " +  userData.getEndpoint() + "/" + userData.getParam1());
        test.log(Status.INFO,"Endpoint: " + fullEndpoint);

        Response response = null;
        try {
            response = given()
                    .when()
                    .get(userData.getEndpoint() + "/" + userData.getParam1()) // Use userId as path parameter
                    .then()
                    .extract().response();

            // Log request and response details
            test.log(Status.INFO, "Request: GET " + fullEndpoint);
            test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
            test.log(Status.INFO, "Response Body: " + response.getBody().asString());

            // Print response details for debugging
            System.out.println("Response Status Code: " + response.getStatusCode());
            System.out.println("Response Body: " + response.getBody().asString());

            // Validate status code
            assertThat("The status code should be 200", response.getStatusCode(), equalTo(200));

            // Validate data fields
            assertThat("The ID should match", response.path("data.id").toString(), equalTo(userData.getExpectedId()));
            assertThat("The email should match", response.path("data.email"), equalTo(userData.getExpectedEmail()));
            assertThat("The first name should match", response.path("data.first_name"), equalTo(userData.getExpectedFirstName()));
            assertThat("The last name should match", response.path("data.last_name"), equalTo(userData.getExpectedLastName()));
            assertThat("The avatar URL should match", response.path("data.avatar"), equalTo(userData.getExpectedAvatar()));

            // Validate support fields
            assertThat("The support URL should match", response.path("support.url"), equalTo(userData.getExpectedSupportUrl()));
            assertThat("The support text should match", response.path("support.text"), equalTo(userData.getExpectedSupportText()));

            test.log(Status.PASS, "Test passed");
        }catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "Test failed: " + e.getMessage());
            if (response != null) {
                test.log(Status.FAIL, "Response Body: " + response.getBody().asString());
            }
            throw e;
        }
    }
}
