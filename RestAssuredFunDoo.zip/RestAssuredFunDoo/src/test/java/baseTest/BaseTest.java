package baseTest;

//import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import utils.ExtentReportListener;
//import utils.ExtentReportListenerOld;
import utils.FileAndEnv;

@Listeners(ExtentReportListener.class)
public class BaseTest extends ExtentReportListener {
//    @Test
//    public void utilsTest(){
//        int a=0;
//        int b=1;
//        int sum=a+b;
//        System.out.println(FileAndEnv.envAndFile().get("ServerUrl"));
//        test.log(LogStatus.INFO,"test has been started");
//        test.log(LogStatus.PASS,"test has passed");
//        test.log(LogStatus.PASS,"My sum value is "+sum);
//        test.log(LogStatus.INFO,"test has been completed");
//    }

    @BeforeClass
    public void baseTest(){
        RestAssured.baseURI=FileAndEnv.envAndFile().get("ServerUrl");
    }
}
