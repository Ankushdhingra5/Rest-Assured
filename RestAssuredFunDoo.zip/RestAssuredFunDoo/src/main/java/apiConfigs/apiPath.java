package apiConfigs;

public class apiPath {
    public static  final class APIPath{
        //GET
        public static final String GET_LIST_OF_USERS="/api/users?page=2";
        public static final String GET_SINGLE_USER="/api/users/2";

        //POST
        public static final String CREATE_USER="/api/users";

        //DELETE
        public static final String DELETE_USER="/api/users/2";

    }

    public static void main(String[] args) {
        System.out.println(APIPath.GET_SINGLE_USER);
    }
}
