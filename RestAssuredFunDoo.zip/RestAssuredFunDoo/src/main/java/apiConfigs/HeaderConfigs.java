package apiConfigs;


import java.util.HashMap;
import java.util.Map;

public class HeaderConfigs {
    public  Map<String,String> defaultHeaders(){
        Map<String,String> defaultHeaders=new HashMap<>();
        defaultHeaders.put("Content-Type","application/json");
        return defaultHeaders;
    }

    public  Map<String,String> headersWithToken(){

        Map<String,String> defaultHeaders=new HashMap<>();
        defaultHeaders.put("Content-Type","application/json");
        defaultHeaders.put("Access_Token","wqwretytjhgfdsfdfgnb");
        defaultHeaders.put("jwt_token","wqwretytjhgfdsfdfgnb");
        defaultHeaders.put("Tenant_user","test");

        return defaultHeaders;
    }


    // just to check
    public static void main(String[] args) {
        HeaderConfigs headerConfigs=new HeaderConfigs();
        System.out.println(headerConfigs.defaultHeaders());
    }
}
