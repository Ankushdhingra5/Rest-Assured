package pojo;

public class UserData {
    private String endpoint;
    private int param1;
    private String expectedId;
    private String expectedEmail;
    private String expectedFirstName;
    private String expectedLastName;
    private String expectedAvatar;
    private String expectedSupportUrl;
    private String expectedSupportText;

    // Getters and setters
    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public int getParam1() {
        return param1;
    }

    public void setParam1(int param1) {
        this.param1 = param1;
    }

    public String getExpectedId() {
        return expectedId;
    }

    public void setExpectedId(String expectedId) {
        this.expectedId = expectedId;
    }

    public String getExpectedEmail() {
        return expectedEmail;
    }

    public void setExpectedEmail(String expectedEmail) {
        this.expectedEmail = expectedEmail;
    }

    public String getExpectedFirstName() {
        return expectedFirstName;
    }

    public void setExpectedFirstName(String expectedFirstName) {
        this.expectedFirstName = expectedFirstName;
    }

    public String getExpectedLastName() {
        return expectedLastName;
    }

    public void setExpectedLastName(String expectedLastName) {
        this.expectedLastName = expectedLastName;
    }

    public String getExpectedAvatar() {
        return expectedAvatar;
    }

    public void setExpectedAvatar(String expectedAvatar) {
        this.expectedAvatar = expectedAvatar;
    }

    public String getExpectedSupportUrl() {
        return expectedSupportUrl;
    }

    public void setExpectedSupportUrl(String expectedSupportUrl) {
        this.expectedSupportUrl = expectedSupportUrl;
    }

    public String getExpectedSupportText() {
        return expectedSupportText;
    }

    public void setExpectedSupportText(String expectedSupportText) {
        this.expectedSupportText = expectedSupportText;
    }
}
