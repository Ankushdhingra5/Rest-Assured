package utils;

import org.apache.commons.lang3.RandomStringUtils;

public class JavaUtils {

    public static String randomString(){
        String randomString= RandomStringUtils.randomAlphabetic(5);
        return randomString;
    }
}
