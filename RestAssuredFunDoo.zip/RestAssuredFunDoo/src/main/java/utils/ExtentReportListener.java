package utils;

import java.io.File;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ExtentReportListener implements ITestListener {
    protected static ExtentReports reports;
    protected static ExtentTest test;

    private static String resultpath = getResultPath();

    public static void deleteDirectory(File directory) {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (null != files) {
                for (int i = 0; i < files.length; i++) {
                    System.out.println(files[i].getName());
                    if (files[i].isDirectory()) {
                        deleteDirectory(files[i]);
                    } else {
                        files[i].delete();
                    }
                }
            }
        }
    }

    private static String getResultPath() {
        resultpath = "test";
        if (!new File(resultpath).isDirectory()) {
            new File(resultpath).mkdirs();
        }
        return resultpath;
    }

    String ReportLocation = "test-output/Report/" + resultpath + "/";

    public void onTestStart(ITestResult result) {
        test = reports.createTest(result.getMethod().getMethodName());
        test.log(Status.INFO, "Test Started: " + result.getMethod().getMethodName());
        System.out.println("Test Started: " + result.getMethod().getMethodName());
    }

    public void onTestSuccess(ITestResult result) {
        test.log(Status.PASS, "Test Passed: " + result.getMethod().getMethodName());
    }

    public void onTestFailure(ITestResult result) {
        test.log(Status.FAIL, "Test Failed: " + result.getMethod().getMethodName());
        test.log(Status.FAIL, result.getThrowable());
    }

    public void onTestSkipped(ITestResult result) {
        test.log(Status.SKIP, "Test Skipped: " + result.getMethod().getMethodName());
    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // not implemented
    }

    public void onStart(ITestContext context) {
        System.out.println(ReportLocation + " ReportLocation");
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter(ReportLocation + "ExtentReport.html");
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle("API Test Report");
        htmlReporter.config().setReportName("API Test Report");

        reports = new ExtentReports();
        reports.attachReporter(htmlReporter);
        reports.setSystemInfo("OS", "Windows");
        reports.setSystemInfo("Environment", "QA");
        reports.setSystemInfo("Tester", "Your Name");
    }

    public void onFinish(ITestContext context) {
        if (test != null) {
            reports.flush();
        }
    }
}
