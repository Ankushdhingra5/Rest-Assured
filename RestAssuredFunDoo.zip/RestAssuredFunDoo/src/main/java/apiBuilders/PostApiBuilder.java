package apiBuilders;

import java.util.HashMap;
import java.util.Map;

public class PostApiBuilder {

    public Map<String,String> postBodyBuilder(String id,String title){
        Map<String,String> body=new HashMap<>();
        body.put("name",id);
        body.put("title",title);
        return body;
    }
}
