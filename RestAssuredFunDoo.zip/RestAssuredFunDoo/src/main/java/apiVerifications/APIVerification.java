package apiVerifications;

//import com.relevantcodes.extentreports.LogStatus;
import com.aventstack.extentreports.Status;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import utils.ExtentReportListener;

public class APIVerification extends ExtentReportListener {

    public static void responseCodeValidator(Response response, int statusCode){
        try{

            Assert.assertEquals(statusCode,response.getStatusCode());
            test.log(Status.PASS,"Successfully Validated status code :: "+response.getStatusCode());


        }catch (AssertionError e){

            test.log(Status.FAIL,e.fillInStackTrace());
            test.log(Status.FAIL,"Expected status code is :: "+statusCode +" , instead of getting :: "+response.getStatusCode());

        }catch (Exception e){

            test.log(Status.FAIL,e.fillInStackTrace());

        }
    }

    public static void responseKeyValidator(Response response,String key){

        try{

            JSONObject jsonObject=new JSONObject(response.getBody().asString());
            test.log(Status.PASS,"Validated value is :"+jsonObject.get(key));

        }catch (Exception e){

            test.log(Status.FAIL,e.fillInStackTrace());

        }
    }

    public static void responseTimeValidator(Response response){

        try{

            long time=response.time();
            test.log(Status.INFO,"API response time is :"+time);

        }catch (Exception e){

            test.log(Status.FAIL,e.fillInStackTrace());

        }
    }
}
